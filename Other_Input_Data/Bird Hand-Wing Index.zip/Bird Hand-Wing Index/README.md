# Global-HWI
Hand-wing index values for 10,338 species of birds
